/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semaforo;

/**
 *
 * @author informatica
 */
public class semaforo {
    
      
 class Semaforo {

    private Semaforo semaforo;

    public Semaforo(int slotLimit) {
        semaforo = new semaforo(slotLimit);
    }

    boolean tryLogin() {
        return semaforo.tryAcquire();
    }

    void logout() {
        semaforo.release();
    }

    int availableSlots() {
        return semaforo.availablePermits();
    }

 }
}
