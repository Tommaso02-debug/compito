/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semaforo;
import java.util.Random;
/**
 *
 * @author informatica
 */

public class bagno {
int clienti;
String tipo; //donne o uomini
public bagno(String b)
{ this.clienti=0;
this.tipo=b;

}

public synchronized void usa_bagno(String TID, Random r)
{ clienti++;
 System.out.print
 try{
 Thread.sleep(r.nextInt(5)*1000);
 }catch(InterruptedException e){}
 System.out.print
 }
}// fine classe

