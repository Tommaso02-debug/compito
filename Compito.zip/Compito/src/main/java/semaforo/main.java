/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semaforo;
import java.util.Random;

/**
 *
 * @author informatica
 */
public class main {
public static void main(String[] args) {
    FINAL=W
int i;
Random r=new Random(System.currentTimeMillis());
bagno buo=new bagno("uomini"); // bagno uomini
bagno bdo=new bagno("donne"); // bagno donne
uomini []U= new uomini[W];
donne []D= new donne[W];
for (i=0; i<W; i++)
{ U[i]=new uomini(buo, r);
D[i]=new donne(bdo, r);
}
for (i=0; i<W; i++)
{ U[i].start();
D[i].start();
        }
    } 
} 
  
